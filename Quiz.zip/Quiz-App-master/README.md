# Quiz-App
Harry Potter quiz app created using android studio

After completing the basic Android course from Udacity, I developed the Harry Potter Quiz App. Using intents and the basic concepts 
